#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a structure to represent the CPU state
typedef struct {
    int eax;
    int ebx;
    int ecx;
    int edx;
} CPUState;

// Initialize the CPU state
CPUState cpu = {0, 0, 0, 0};

// Function to handle the 'mov' instruction
void handle_mov(char* dest, char* src) {
    int value;
    if (src[0] == 'e') {
        // The source is a register
        if (strcmp(src, "eax") == 0) value = cpu.eax;
        else if (strcmp(src, "ebx") == 0) value = cpu.ebx;
        else if (strcmp(src, "ecx") == 0) value = cpu.ecx;
        else if (strcmp(src, "edx") == 0) value = cpu.edx;
        else {
            fprintf(stderr, "Unknown register: %s\n", src);
            exit(EXIT_FAILURE);
        }
    } else {
        // The source is an immediate value
        value = atoi(src);
    }

    // Update the destination register
    if (strcmp(dest, "eax") == 0) cpu.eax = value;
    else if (strcmp(dest, "ebx") == 0) cpu.ebx = value;
    else if (strcmp(dest, "ecx") == 0) cpu.ecx = value;
    else if (strcmp(dest, "edx") == 0) cpu.edx = value;
    else {
        fprintf(stderr, "Unknown register: %s\n", dest);
        exit(EXIT_FAILURE);
    }
}

// Function to parse and execute an instruction
void execute_instruction(char* instruction) {
    char* opcode = strtok(instruction, " ");
    char* op1 = strtok(NULL, " ");
    char* op2 = strtok(NULL, " ");

    if (strcmp(opcode, "mov") == 0) {
        handle_mov(op1, op2);
    } else {
        fprintf(stderr, "Unknown opcode: %s\n", opcode);
        exit(EXIT_FAILURE);
    }
}

// Your existing code goes here...

int main(int argc, char **argv){
    // Your existing code goes here...

    // Example usage:
    execute_instruction("mov eax 10");
    execute_instruction("mov ebx eax");
    printf("eax: %d, ebx: %d\n", cpu.eax, cpu.ebx);  // Outputs: eax: 10, ebx: 10

    return 0;
}
